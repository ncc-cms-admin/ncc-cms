# NCC CMS — Foundation Build v0.3

A first working, cloud-deployable application foundation for a battalion-level NCC camp-management workflow. This is **not approved for operational NCC data** and is not a completed production system. Use synthetic test records only until the competent authority approves hosting, data handling and security controls.

## What works in this build

- Responsive browser UI for phone and laptop.
- Username/password login; signed server-side session cookie; CSRF token on mutating requests.
- Server-enforced role checks for administrator, camp administrator, registration, attendance, feeding, medical, finance and viewer roles.
- Camp setup.
- Manual cadet registration with per-camp duplicate enrolment check.
- Generated QR containing only an opaque random token, not the cadet's personal data.
- Token lookup by an authorised user.
- Attendance entry and daily attendance listing.
- Meal-wise feeding entries for cadets, staff and guests.
- Audit events for important operations.
- Optional image upload endpoint with file-type, image validation and 5 MB cap; private directory is outside the public static web root. Production storage encryption/access controls still need configuration.
- SQLite for local development; PostgreSQL connection string supported through `DATABASE_URL`.

## Not implemented yet

Camera-based QR scanning in the browser, existing official NCC QR-format import, medical records, out-pass/movement timeline, early departure/return workflow, ANO/GCI/PI joining/departure, accommodation, training/tests, budget/vouchers, stores/inventory, document approvals, exportable PDF/Excel reports, password reset, MFA, automatic account expiry, database migrations, production rate-limiting, central log aggregation and hardened object storage.

No official NCC rules, rates, approval chains or QR formats are inferred in code. Those require verified current instructions or sample formats supplied by the competent authority.

## Local development (test data only)

Requires Python 3.11+ recommended.

1. Create a virtual environment and install dependencies:

   ```bash
   python -m venv .venv
   # Linux/macOS
   source .venv/bin/activate
   # Windows PowerShell: .venv\\Scripts\\Activate.ps1
   pip install -r requirements.txt
   ```

2. Set environment variables before starting. Example for Linux/macOS:

   ```bash
   export APP_ENV=development
   export SESSION_SECRET="replace-with-a-long-random-secret-value"
   export DATABASE_URL="sqlite:///./ncc_camp_hq.db"
   export BOOTSTRAP_ADMIN_USERNAME="admin"
   export BOOTSTRAP_ADMIN_PASSWORD="Replace-With-A-Unique-Long-Password!"
   export COOKIE_SECURE=false
   export UPLOAD_DIR="./private_uploads"
   uvicorn app.main:app --host 127.0.0.1 --port 8000
   ```

3. Open `http://127.0.0.1:8000` on that computer. The bootstrap administrator is created only if the configured username does not already exist. Do not expose the development server directly to the internet.

For a phone to open a locally running app, the phone must be on the same trusted Wi-Fi/LAN and the server must be bound to a LAN interface; firewall rules and local-network controls matter. Do not do this with real data until approved. A cloud deployment is a separate, authorised deployment step requiring HTTPS and `COOKIE_SECURE=true`.

## PostgreSQL

Set `DATABASE_URL` to an approved PostgreSQL connection URI, for example `postgresql+psycopg://USER:PASSWORD@HOST:5432/DBNAME`. Use secret management rather than committing credentials. The current build creates tables on startup; before production, replace this with versioned migrations and a reviewed backup/restore procedure.

## Tests

```bash
pytest -q
```

The automated tests cover login, CSRF, camp/cadet registration, duplicate rejection, QR image response/token lookup, attendance and feeding flow. Passing tests do not constitute a security audit or operational approval.

## Mandatory before production

- Written approval for the cloud/provider, data categories, access method and retention.
- Review current applicable NCC/Defence IT, cybersecurity, privacy and procurement requirements.
- HTTPS reverse proxy; secure cookie; strong managed secrets; rate limiting; MFA or approved identity provider; password-reset/expiry process; account lockout controls.
- PostgreSQL migrations, least-privilege DB account, encrypted storage/backups, tested restore, monitoring and incident response.
- Security audit/penetration test by the designated authority; dependency scanning; server hardening.
- Private object storage for photographs, access-controlled delivery, encryption at rest, backup and retention/deletion policy.
- Review role matrix with actual camp appointments; medical information must remain separately permissioned and minimised.
- Verify official QR format, feeding cut-offs/rates, movement approvals and all report formats against current authorised instructions.

## Structure

- `app/main.py` — API, models, authentication, role checks and audit.
- `app/static/index.html` — responsive web interface.
- `tests/test_core.py` — basic integration tests.
- `requirements.txt` — dependencies.


Branding note: this build includes a locally bundled NCC-inspired emblem graphic in `app/static/ncc-logo.svg`. Replace it with an authorised official logo asset if one is supplied/required by the competent authority.
