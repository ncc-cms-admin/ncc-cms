# Deployment notes (review required before use)

This project can be containerised, but the Dockerfile is not an approval to host real NCC data. The hosting organisation/provider, region, data categories, identity/access model, logging, backup and incident response must be approved first.

For a cloud deployment, use a managed secret store and an approved PostgreSQL service; set `APP_ENV=production`, `SESSION_SECRET` to a cryptographically random value of at least 32 characters, `COOKIE_SECURE=true`, `DATABASE_URL` to PostgreSQL, and `UPLOAD_DIR` to private persistent storage. Terminate HTTPS at an approved reverse proxy/load balancer. Do not expose port 8000 directly to the public internet. Configure ingress restrictions, rate limits, central logs, monitoring, database backups, tested restore and encrypted private object storage. Never commit secrets to source control.

The current release is an engineering foundation only. It does not yet include a migration system, MFA, rate limiting, account lockout, complete password reset, hardened photo object storage, complete production monitoring or an independent security audit. These are release blockers for operational use.
