from __future__ import annotations

import base64
import hashlib
import hmac
import io
import os
import secrets
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Generator

import qrcode
from fastapi import Depends, FastAPI, HTTPException, Request, Response, UploadFile, File
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

APP_ENV = os.getenv("APP_ENV", "development").lower()
SESSION_SECRET = os.getenv("SESSION_SECRET", "development-only-secret-change-before-deploy")
if APP_ENV == "production" and (len(SESSION_SECRET) < 32 or SESSION_SECRET == "development-only-secret-change-before-deploy"):
    raise RuntimeError("Production requires a strong SESSION_SECRET of at least 32 characters.")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ncc_camp_hq.db")
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "false").lower() == "true"
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "./private_uploads")).resolve()
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(32), default="viewer")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Camp(Base):
    __tablename__ = "camps"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    unit_name: Mapped[str] = mapped_column(String(180))
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Cadet(Base):
    __tablename__ = "cadets"
    __table_args__ = (UniqueConstraint("camp_id", "enrolment_no", name="uq_cadet_camp_enrolment"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    camp_id: Mapped[int] = mapped_column(ForeignKey("camps.id"), index=True)
    enrolment_no: Mapped[str] = mapped_column(String(80), index=True)
    full_name: Mapped[str] = mapped_column(String(180), index=True)
    institution: Mapped[str] = mapped_column(String(180), default="")
    division: Mapped[str] = mapped_column(String(20), default="")
    class_year: Mapped[str] = mapped_column(String(80), default="")
    phone: Mapped[str] = mapped_column(String(40), default="")
    emergency_contact: Mapped[str] = mapped_column(String(80), default="")
    photo_key: Mapped[str | None] = mapped_column(String(120), nullable=True)
    qr_token: Mapped[str] = mapped_column(String(64), unique=True, index=True, default=lambda: secrets.token_urlsafe(24))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Attendance(Base):
    __tablename__ = "attendance"
    __table_args__ = (UniqueConstraint("cadet_id", "attendance_date", name="uq_attendance_cadet_date"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cadet_id: Mapped[int] = mapped_column(ForeignKey("cadets.id"), index=True)
    attendance_date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(32))
    note: Mapped[str] = mapped_column(String(300), default="")
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class FeedingRecord(Base):
    __tablename__ = "feeding_records"
    __table_args__ = (UniqueConstraint("camp_id", "feeding_date", "meal", name="uq_feeding_camp_date_meal"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    camp_id: Mapped[int] = mapped_column(ForeignKey("camps.id"), index=True)
    feeding_date: Mapped[date] = mapped_column(Date, index=True)
    meal: Mapped[str] = mapped_column(String(20))
    cadets: Mapped[int] = mapped_column(Integer, default=0)
    staff: Mapped[int] = mapped_column(Integer, default=0)
    guests: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(String(300), default="")
    recorded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80), default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)

Base.metadata.create_all(engine)

# Passwords use stdlib PBKDF2-HMAC-SHA256 with a per-user random salt.
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return "pbkdf2_sha256$310000$" + base64.urlsafe_b64encode(salt).decode() + "$" + base64.urlsafe_b64encode(digest).decode()

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, rounds, salt_b64, digest_b64 = stored.split("$")
        if scheme != "pbkdf2_sha256": return False
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(digest_b64.encode())
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, int(rounds))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try: yield db
    finally: db.close()

def bootstrap_admin() -> None:
    username = os.getenv("BOOTSTRAP_ADMIN_USERNAME", "").strip()
    password = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "")
    if not username or not password: return
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.username == username)) is None:
            db.add(User(username=username, password_hash=hash_password(password), role="admin", active=True))
            db.commit()
bootstrap_admin()

app = FastAPI(title="NCC CMS", version="0.3.0", docs_url=None if APP_ENV == "production" else "/docs", redoc_url=None)
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

ROLE_PERMISSIONS = {
    "admin": {"*"},
    "camp_admin": {"dashboard:read", "camps:read", "cadets:sensitive_read", "cadets:photo_read", "cadets:read", "cadets:write", "attendance:read", "attendance:write", "feeding:read", "feeding:write", "reports:read", "staff:read"},
    "registration": {"dashboard:read", "camps:read", "cadets:sensitive_read", "cadets:photo_read", "cadets:read", "cadets:write", "reports:read"},
    "attendance": {"dashboard:read", "camps:read", "cadets:read", "attendance:read", "attendance:write", "reports:read"},
    "feeding": {"dashboard:read", "camps:read", "feeding:read", "feeding:write", "reports:read"},
    "medical": {"dashboard:read", "camps:read", "medical:read", "medical:write"},
    "finance": {"dashboard:read", "camps:read", "finance:read", "finance:write", "reports:read"},
    "viewer": {"dashboard:read", "camps:read", "cadets:read", "attendance:read", "feeding:read", "reports:read"},
}

def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    user_id = request.session.get("user_id")
    if not user_id: raise HTTPException(status_code=401, detail="Please sign in")
    user = db.get(User, int(user_id))
    if not user or not user.active:
        request.session.clear(); raise HTTPException(status_code=401, detail="Account inactive or session expired")
    return user

def require(permission: str):
    def dep(user: User = Depends(current_user)) -> User:
        allowed = ROLE_PERMISSIONS.get(user.role, set())
        if "*" not in allowed and permission not in allowed:
            raise HTTPException(status_code=403, detail="Your account is not authorised for this action")
        return user
    return dep

def audit(db: Session, user: User | None, action: str, entity_type: str, entity_id: str = "", detail: str = "") -> None:
    db.add(AuditEvent(user_id=user.id if user else None, action=action, entity_type=entity_type, entity_id=str(entity_id), detail=detail[:1000]))

class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=256)
class CampIn(BaseModel):
    name: str = Field(min_length=2, max_length=180)
    unit_name: str = Field(min_length=2, max_length=180)
    start_date: date | None = None
    end_date: date | None = None
class CadetIn(BaseModel):
    camp_id: int
    enrolment_no: str = Field(min_length=1, max_length=80)
    full_name: str = Field(min_length=2, max_length=180)
    institution: str = Field(default="", max_length=180)
    division: str = Field(default="", max_length=20)
    class_year: str = Field(default="", max_length=80)
    phone: str = Field(default="", max_length=40)
    emergency_contact: str = Field(default="", max_length=80)
class AttendanceIn(BaseModel):
    cadet_id: int
    attendance_date: date = Field(default_factory=date.today)
    status: str = Field(pattern="^(present|absent|out_pass|medical|left_early|authorised_absence|late)$")
    note: str = Field(default="", max_length=300)
class FeedingIn(BaseModel):
    camp_id: int
    feeding_date: date = Field(default_factory=date.today)
    meal: str = Field(pattern="^(breakfast|lunch|dinner|snacks)$")
    cadets: int = Field(ge=0, le=100000)
    staff: int = Field(ge=0, le=10000)
    guests: int = Field(ge=0, le=10000)
    note: str = Field(default="", max_length=300)
class UserIn(BaseModel):
    username: str = Field(min_length=3, max_length=80, pattern="^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=14, max_length=256)
    role: str = Field(pattern="^(camp_admin|registration|attendance|feeding|medical|finance|viewer)$")

@app.get("/", response_class=HTMLResponse)
def home():
    return (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"status": "ok", "app": "NCC CMS", "version": "0.3.0"}

@app.post("/api/login")
def login(payload: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == payload.username))
    if not user or not user.active or not verify_password(payload.password, user.password_hash):
        audit(db, user, "login_failed", "user", str(user.id) if user else "", "Invalid login")
        db.commit()
        raise HTTPException(status_code=401, detail="Invalid username or password")
    request.session.clear()
    request.session["user_id"] = user.id
    request.session["csrf"] = secrets.token_urlsafe(32)
    audit(db, user, "login_success", "user", user.id)
    db.commit()
    return {"username": user.username, "role": user.role, "csrf_token": request.session["csrf"]}

@app.post("/api/logout")
def logout(request: Request, user: User = Depends(current_user)):
    request.session.clear()
    return {"ok": True}

@app.get("/api/me")
def me(request: Request, user: User = Depends(current_user)):
    return {"username": user.username, "role": user.role, "csrf_token": request.session.get("csrf")}

def csrf_guard(request: Request) -> None:
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and request.url.path not in {"/api/login"}:
        supplied = request.headers.get("x-csrf-token", "")
        expected = request.session.get("csrf", "")
        if not supplied or not expected or not hmac.compare_digest(supplied, expected):
            raise HTTPException(status_code=403, detail="CSRF validation failed")

@app.middleware("http")
async def csrf_middleware(request: Request, call_next):
    if request.url.path.startswith("/api/") and request.method in {"POST", "PUT", "PATCH", "DELETE"} and request.url.path != "/api/login":
        supplied = request.headers.get("x-csrf-token", "")
        expected = request.session.get("csrf", "")
        if not supplied or not expected or not hmac.compare_digest(supplied, expected):
            from starlette.responses import JSONResponse
            return JSONResponse({"detail": "CSRF validation failed"}, status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    if APP_ENV == "production": response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

# Session middleware must wrap the CSRF middleware so request.session is available.
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET, session_cookie="ncc_camp_session", same_site="strict", https_only=COOKIE_SECURE, max_age=60 * 60 * 8)

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(require("dashboard:read"))):
    camps = db.scalars(select(Camp).where(Camp.active.is_(True)).order_by(Camp.id.desc())).all()
    cadet_count = db.scalar(select(Cadet.id).where(Cadet.active.is_(True)).count()) if False else len(db.scalars(select(Cadet).where(Cadet.active.is_(True))).all())
    return {"user": {"username": user.username, "role": user.role}, "active_camps": len(camps), "active_cadets": cadet_count,
            "camps": [{"id": c.id, "name": c.name, "unit_name": c.unit_name, "start_date": str(c.start_date or ""), "end_date": str(c.end_date or "")} for c in camps]}

@app.post("/api/camps")
def create_camp(payload: CampIn, db: Session = Depends(get_db), user: User = Depends(require("*"))):
    if payload.end_date and payload.start_date and payload.end_date < payload.start_date:
        raise HTTPException(status_code=422, detail="End date cannot precede start date")
    camp = Camp(**payload.model_dump())
    db.add(camp); db.flush(); audit(db, user, "camp_created", "camp", camp.id, camp.name); db.commit(); db.refresh(camp)
    return {"id": camp.id, "name": camp.name, "unit_name": camp.unit_name, "start_date": str(camp.start_date or ""), "end_date": str(camp.end_date or "")}

@app.get("/api/camps")
def list_camps(db: Session = Depends(get_db), user: User = Depends(require("camps:read"))):
    return [{"id": c.id, "name": c.name, "unit_name": c.unit_name} for c in db.scalars(select(Camp).where(Camp.active.is_(True)).order_by(Camp.id.desc())).all()]

@app.post("/api/users")
def create_user(payload: UserIn, db: Session = Depends(get_db), user: User = Depends(require("*"))):
    if db.scalar(select(User).where(User.username == payload.username)):
        raise HTTPException(status_code=409, detail="Username already exists")
    new_user = User(username=payload.username, password_hash=hash_password(payload.password), role=payload.role, active=True)
    db.add(new_user); db.flush(); audit(db, user, "user_created", "user", new_user.id, f"role={new_user.role}"); db.commit()
    return {"id": new_user.id, "username": new_user.username, "role": new_user.role}

@app.post("/api/cadets")
def create_cadet(payload: CadetIn, db: Session = Depends(get_db), user: User = Depends(require("cadets:write"))):
    if not db.get(Camp, payload.camp_id): raise HTTPException(status_code=404, detail="Camp not found")
    if db.scalar(select(Cadet).where(Cadet.camp_id == payload.camp_id, Cadet.enrolment_no == payload.enrolment_no)):
        raise HTTPException(status_code=409, detail="This enrolment number is already registered for this camp")
    cadet = Cadet(**payload.model_dump(), qr_token=secrets.token_urlsafe(24))
    db.add(cadet); db.flush(); audit(db, user, "cadet_registered", "cadet", cadet.id, f"camp_id={cadet.camp_id}"); db.commit(); db.refresh(cadet)
    return cadet_public(cadet)

def cadet_public(c: Cadet):
    # General lists and QR lookup deliberately omit direct contact details.
    return {"id": c.id, "camp_id": c.camp_id, "enrolment_no": c.enrolment_no, "full_name": c.full_name, "institution": c.institution,
            "division": c.division, "class_year": c.class_year, "has_photo": bool(c.photo_key),
            "created_at": c.created_at.isoformat(), "qr_url": f"/api/cadets/{c.id}/qr"}

@app.get("/api/cadets/{cadet_id}/sensitive")
def cadet_sensitive_details(cadet_id: int, db: Session = Depends(get_db), user: User = Depends(require("cadets:sensitive_read"))):
    cadet = db.get(Cadet, cadet_id)
    if not cadet: raise HTTPException(status_code=404, detail="Cadet not found")
    audit(db, user, "sensitive_cadet_details_viewed", "cadet", cadet.id)
    db.commit()
    return {"id": cadet.id, "phone": cadet.phone, "emergency_contact": cadet.emergency_contact}

@app.get("/api/cadets")
def list_cadets(camp_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require("cadets:read"))):
    query = select(Cadet).where(Cadet.active.is_(True)).order_by(Cadet.full_name)
    if camp_id: query = query.where(Cadet.camp_id == camp_id)
    return [cadet_public(c) for c in db.scalars(query).all()]

@app.get("/api/cadets/{cadet_id}/qr")
def cadet_qr(cadet_id: int, db: Session = Depends(get_db), user: User = Depends(require("cadets:read"))):
    cadet = db.get(Cadet, cadet_id)
    if not cadet: raise HTTPException(status_code=404, detail="Cadet not found")
    # QR carries an opaque random token only; it does not contain PII or medical information.
    img = qrcode.make(cadet.qr_token)
    out = io.BytesIO(); img.save(out, format="PNG"); out.seek(0)
    audit(db, user, "cadet_qr_generated", "cadet", cadet.id); db.commit()
    return StreamingResponse(out, media_type="image/png", headers={"Cache-Control": "no-store"})

@app.get("/api/qr/lookup")
def qr_lookup(token: str, db: Session = Depends(get_db), user: User = Depends(require("cadets:read"))):
    if len(token) < 20 or len(token) > 100: raise HTTPException(status_code=400, detail="Invalid token format")
    cadet = db.scalar(select(Cadet).where(Cadet.qr_token == token, Cadet.active.is_(True)))
    if not cadet: raise HTTPException(status_code=404, detail="No matching active cadet record")
    audit(db, user, "qr_lookup", "cadet", cadet.id); db.commit()
    return cadet_public(cadet)

@app.post("/api/attendance")
def mark_attendance(payload: AttendanceIn, db: Session = Depends(get_db), user: User = Depends(require("attendance:write"))):
    cadet = db.get(Cadet, payload.cadet_id)
    if not cadet: raise HTTPException(status_code=404, detail="Cadet not found")
    row = db.scalar(select(Attendance).where(Attendance.cadet_id == payload.cadet_id, Attendance.attendance_date == payload.attendance_date))
    if row:
        old_status = row.status; row.status = payload.status; row.note = payload.note; row.recorded_by = user.id
        audit(db, user, "attendance_updated", "attendance", row.id, f"{old_status}->{row.status}; date={row.attendance_date}")
    else:
        row = Attendance(**payload.model_dump(), recorded_by=user.id); db.add(row); db.flush()
        audit(db, user, "attendance_marked", "attendance", row.id, f"status={row.status}; date={row.attendance_date}")
    db.commit()
    return {"id": row.id, "cadet_id": row.cadet_id, "date": str(row.attendance_date), "status": row.status, "note": row.note}

@app.get("/api/attendance")
def attendance_report(attendance_date: date | None = None, camp_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(require("attendance:read"))):
    attendance_date = attendance_date or date.today()
    query = select(Attendance, Cadet).join(Cadet, Attendance.cadet_id == Cadet.id).where(Attendance.attendance_date == attendance_date)
    if camp_id: query = query.where(Cadet.camp_id == camp_id)
    return [{"cadet_id": c.id, "enrolment_no": c.enrolment_no, "full_name": c.full_name, "date": str(a.attendance_date), "status": a.status, "note": a.note} for a, c in db.execute(query).all()]

@app.post("/api/feeding")
def save_feeding(payload: FeedingIn, db: Session = Depends(get_db), user: User = Depends(require("feeding:write"))):
    if not db.get(Camp, payload.camp_id): raise HTTPException(status_code=404, detail="Camp not found")
    row = db.scalar(select(FeedingRecord).where(FeedingRecord.camp_id == payload.camp_id, FeedingRecord.feeding_date == payload.feeding_date, FeedingRecord.meal == payload.meal))
    if row:
        row.cadets, row.staff, row.guests, row.note, row.recorded_by = payload.cadets, payload.staff, payload.guests, payload.note, user.id
        audit(db, user, "feeding_updated", "feeding_record", row.id, f"{row.feeding_date} {row.meal}")
    else:
        row = FeedingRecord(**payload.model_dump(), recorded_by=user.id); db.add(row); db.flush()
        audit(db, user, "feeding_recorded", "feeding_record", row.id, f"{row.feeding_date} {row.meal}")
    db.commit()
    return {"id": row.id, "camp_id": row.camp_id, "date": str(row.feeding_date), "meal": row.meal, "cadets": row.cadets, "staff": row.staff, "guests": row.guests, "total": row.cadets + row.staff + row.guests}

@app.get("/api/feeding")
def feeding_report(camp_id: int, feeding_date: date | None = None, db: Session = Depends(get_db), user: User = Depends(require("feeding:read"))):
    feeding_date = feeding_date or date.today()
    rows = db.scalars(select(FeedingRecord).where(FeedingRecord.camp_id == camp_id, FeedingRecord.feeding_date == feeding_date).order_by(FeedingRecord.meal)).all()
    return [{"id": r.id, "date": str(r.feeding_date), "meal": r.meal, "cadets": r.cadets, "staff": r.staff, "guests": r.guests, "total": r.cadets+r.staff+r.guests, "note": r.note} for r in rows]

@app.get("/api/audit")
def audit_report(limit: int = 100, db: Session = Depends(get_db), user: User = Depends(require("*"))):
    limit = min(max(limit, 1), 500)
    rows = db.scalars(select(AuditEvent).order_by(AuditEvent.id.desc()).limit(limit)).all()
    return [{"id": r.id, "user_id": r.user_id, "action": r.action, "entity_type": r.entity_type, "entity_id": r.entity_id, "detail": r.detail, "created_at": r.created_at.isoformat()} for r in rows]

@app.get("/api/cadets/{cadet_id}/photo")
def get_cadet_photo(cadet_id: int, db: Session = Depends(get_db), user: User = Depends(require("cadets:photo_read"))):
    cadet = db.get(Cadet, cadet_id)
    if not cadet or not cadet.photo_key: raise HTTPException(status_code=404, detail="Photo not found")
    # photo_key is generated server-side; resolve and constrain it to the private upload directory.
    path = (UPLOAD_DIR / cadet.photo_key).resolve()
    if path.parent != UPLOAD_DIR or not path.is_file(): raise HTTPException(status_code=404, detail="Photo not found")
    audit(db, user, "cadet_photo_viewed", "cadet", cadet.id)
    db.commit()
    suffix = path.suffix.lower()
    media = {".jpg":"image/jpeg", ".png":"image/png", ".webp":"image/webp"}.get(suffix, "application/octet-stream")
    return FileResponse(path, media_type=media, headers={"Cache-Control":"no-store", "X-Content-Type-Options":"nosniff"})

@app.post("/api/cadets/{cadet_id}/photo")
async def upload_cadet_photo(cadet_id: int, file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(require("cadets:write"))):
    cadet = db.get(Cadet, cadet_id)
    if not cadet: raise HTTPException(status_code=404, detail="Cadet not found")
    if file.content_type not in {"image/jpeg", "image/png", "image/webp"}: raise HTTPException(status_code=415, detail="Only JPEG, PNG or WebP images are accepted")
    raw = await file.read(5 * 1024 * 1024 + 1)
    if len(raw) > 5 * 1024 * 1024: raise HTTPException(status_code=413, detail="Image exceeds 5 MB limit")
    try:
        from PIL import Image
        image = Image.open(io.BytesIO(raw)); image.verify()
    except Exception: raise HTTPException(status_code=400, detail="Invalid image file")
    suffix = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}[file.content_type]
    key = f"{uuid.uuid4().hex}{suffix}"
    (UPLOAD_DIR / key).write_bytes(raw)
    cadet.photo_key = key
    audit(db, user, "cadet_photo_uploaded", "cadet", cadet.id, "private photo storage key assigned")
    db.commit()
    return {"ok": True, "has_photo": True, "note": "Photo stored outside the public web directory. Production storage encryption and backup must be configured."}
