import os
import sys
import tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

TMP = tempfile.TemporaryDirectory()
os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(TMP.name) / "test.db")
os.environ["SESSION_SECRET"] = "test-secret-long-enough-for-tests-123456789"
os.environ["BOOTSTRAP_ADMIN_USERNAME"] = "testadmin"
os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "Test-Admin-Password-12345!"
os.environ["UPLOAD_DIR"] = str(Path(TMP.name) / "uploads")

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def login():
    r = client.post("/api/login", json={"username": "testadmin", "password": "Test-Admin-Password-12345!"})
    assert r.status_code == 200, r.text
    return r.json()["csrf_token"]

def test_login_and_dashboard():
    csrf = login()
    r = client.get("/api/dashboard")
    assert r.status_code == 200
    assert "active_camps" in r.json()
    assert csrf

def test_camp_cadet_qr_attendance_feeding_flow():
    csrf = login()
    h = {"X-CSRF-Token": csrf}
    camp = client.post("/api/camps", headers=h, json={"name":"Test ATC", "unit_name":"Test Unit", "start_date":"2026-10-26", "end_date":"2026-11-04"})
    assert camp.status_code == 200, camp.text
    camp_id = camp.json()["id"]
    cadet = client.post("/api/cadets", headers=h, json={"camp_id":camp_id,"enrolment_no":"TEST-001","full_name":"Example Cadet","institution":"Test College","division":"SD","class_year":"I"})
    assert cadet.status_code == 200, cadet.text
    cadet_data = cadet.json()
    assert "qr_token" not in cadet_data
    qr = client.get(cadet_data["qr_url"])
    assert qr.status_code == 200 and qr.headers["content-type"] == "image/png"
    # The token is intentionally not exposed by the normal cadet response; test QR decoding separately via generated token from DB.
    from app.main import SessionLocal, Cadet
    with SessionLocal() as db:
        token = db.get(Cadet, cadet_data["id"]).qr_token
    lookup = client.get("/api/qr/lookup", params={"token":token})
    assert lookup.status_code == 200
    att = client.post("/api/attendance", headers=h, json={"cadet_id":cadet_data["id"],"attendance_date":"2026-10-28","status":"present"})
    assert att.status_code == 200, att.text
    feed = client.post("/api/feeding", headers=h, json={"camp_id":camp_id,"feeding_date":"2026-10-28","meal":"lunch","cadets":10,"staff":3,"guests":2})
    assert feed.status_code == 200 and feed.json()["total"] == 15

def test_csrf_required_for_mutation():
    login()
    r = client.post("/api/camps", json={"name":"Test Camp", "unit_name":"Test Unit"})
    assert r.status_code == 403

def test_duplicate_cadet_rejected():
    csrf = login(); h = {"X-CSRF-Token":csrf}
    camp = client.post("/api/camps", headers=h, json={"name":"Duplicate Test Camp", "unit_name":"Test Unit"}).json()
    payload={"camp_id":camp["id"],"enrolment_no":"DUP-1","full_name":"Example Cadet"}
    assert client.post("/api/cadets", headers=h, json=payload).status_code == 200
    r = client.post("/api/cadets", headers=h, json=payload)
    assert r.status_code == 409
