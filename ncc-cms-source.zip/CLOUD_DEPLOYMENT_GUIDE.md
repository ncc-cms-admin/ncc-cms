# NCC CMS — Cloud Deployment Guide (TEST DATA ONLY)

## Important
This guide is for a temporary demonstration using synthetic data only. Do not upload real NCC cadet information, photos, medical information, or operational records to a public cloud service unless the competent authority has approved the provider, data categories, security design, and deployment.

## What you need
- A GitHub account (or another Git provider supported by your hosting provider).
- A Render account linked to that GitHub account.
- A private GitHub repository is recommended for source code.
- No Python installation is needed on your laptop; the cloud builder installs the dependencies.

## A. Put the source in GitHub
1. On the laptop, download and extract `NCC_CMS_Cloud_Deployment_Pack.zip`.
2. Sign in to GitHub and create a new repository named `ncc-cms`.
3. Keep the source repository private. Do not put secrets, passwords, real cadet data, or photos in it.
4. Upload the contents of this folder to the repository root, including `Dockerfile`, `requirements.txt`, `app/`, and `tests/`. Do not upload `.env` files or database files.
5. Confirm that `Dockerfile` and `requirements.txt` are visible at the top level of the repository.

## B. Create a temporary demo service on Render
1. Sign in at https://render.com/ and connect your GitHub account.
2. Choose **New → Web Service**, then select the `ncc-cms` repository.
3. Choose **Docker** as the runtime. Keep the Dockerfile path as `./Dockerfile`.
4. For a demo, choose an available plan only after reviewing its price and limitations. A free service may sleep when idle and its local filesystem may be ephemeral.
5. Add environment variables in the service settings:
   - `APP_ENV` = `production`
   - `SESSION_SECRET` = generate a random secret of at least 32 characters; do not reuse a password
   - `COOKIE_SECURE` = `true`
   - `BOOTSTRAP_ADMIN_USERNAME` = choose a unique administrator username
   - `BOOTSTRAP_ADMIN_PASSWORD` = set a unique, strong temporary password
   - `DATABASE_URL` = use a PostgreSQL database connection string if a persistent database is configured; do not assume local SQLite storage is durable on a cloud instance
   - `UPLOAD_DIR` = a private persistent storage location only if such storage has been properly configured; otherwise do not test photo uploads
6. Deploy and wait for the provider to report success. The provider will display the actual generated web URL. Do not guess or pre-create a URL.
7. Open the URL and test only with synthetic records. Change/remove the temporary credentials after testing and shut down the demo if it is no longer needed.

## Before any operational deployment
A demo URL is not approval to process NCC data. Obtain written approval for hosting and data handling. A production deployment also requires a persistent approved PostgreSQL database, private object storage for photos, migrations, tested backups/restoration, MFA or approved identity provider, rate limits, account lockout and recovery, central logs, monitoring, security audit, and review of all official rules/report formats. These are not all implemented in this foundation build.

## Current scope
This build includes login/session handling, server-side role checks, camp setup, manual cadet registration, generated opaque QR identifiers and token lookup, attendance, meal-wise feeding entries, audit events, and optional photo-upload endpoint. Browser camera scanning and medical, movement/out-pass, early departure/return, ANO/GCI/PI, accommodation, training, finance, stores and report-export modules remain to be built.
